package com.mobilecomputinghomework.kitchenhelper

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController

class kitchenHelperState (
    val navController: NavHostController
){
    fun navigateBack(){
        navController.popBackStack()
    }
}


@Composable
fun rememberKitchenHelperState(
    navController: NavHostController = rememberNavController()

) = remember(navController){
    kitchenHelperState(navController)
}