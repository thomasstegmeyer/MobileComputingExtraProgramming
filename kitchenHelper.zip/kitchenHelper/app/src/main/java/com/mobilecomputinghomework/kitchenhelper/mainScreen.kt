package com.mobilecomputinghomework.kitchenhelper

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.SnackbarDefaults.backgroundColor
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding

@Composable
fun Main(
    navController: NavController
){
    Column(
        modifier = Modifier
            .systemBarsPadding()
            .padding(15.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        TopAppBar(
            title = { Text(
                text = "Kitchen Helper",
                color = MaterialTheme.colors.primary,
                modifier = Modifier
                    .padding(start = 0.dp)
                    .heightIn(max = 24.dp))
            }
        )

        Spacer(modifier = Modifier.height(20.dp))
        Text(text = "What do you want me to calculate?")
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = {navController.navigate("Volume")},
            enabled = true,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.small
        ) {
            Text(text = "Volume")
        }
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = {navController.navigate("Weight")},
            enabled = true,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.small
        ) {
            Text(text = "Weight")
        }
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = {navController.navigate("Temperature")},
            enabled = true,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.small
        ) {
            Text(text = "Temperature")
        }
    }
}