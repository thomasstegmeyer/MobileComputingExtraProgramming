package com.mobilecomputinghomework.kitchenhelper.ui.theme

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.mobilecomputinghomework.kitchenhelper.Main
import com.mobilecomputinghomework.kitchenhelper.calculators.Temperature
import com.mobilecomputinghomework.kitchenhelper.calculators.Volume
import com.mobilecomputinghomework.kitchenhelper.calculators.Weight
import com.mobilecomputinghomework.kitchenhelper.kitchenHelperState
import com.mobilecomputinghomework.kitchenhelper.rememberKitchenHelperState

@Composable
fun kitchenHelper(
    appState: kitchenHelperState = rememberKitchenHelperState()
){
    NavHost(
        navController = appState.navController,
        startDestination = "Main"
    ){
        composable(route = "Main"){
            Main(navController = appState.navController)
        }
        composable(route = "Volume"){
            Volume(navController = appState.navController)
        }
        composable(route = "Weight"){
            Weight(navController = appState.navController)
        }
        composable(route = "Temperature"){
            Temperature(navController = appState.navController)
        }

    }


}