package com.mobilecomputinghomework.kitchenhelper.calculators

import android.view.Gravity
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.SnackbarDefaults.backgroundColor
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.accompanist.insets.systemBarsPadding


@Composable
fun Volume(
    navController: NavController
){
    val context = LocalContext.current
    val metric = rememberSaveable(){ mutableStateOf("0") }
    val cup = rememberSaveable() { mutableStateOf( "0") }



    Column(
        modifier = Modifier
            .systemBarsPadding()
            .padding(15.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        TopAppBar(
            title = {
                IconButton(onClick = { navController.navigate("Main") }) {
                    Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {}
        )
        Spacer(modifier = Modifier.height(20.dp))
        Text(text = "Cup measurement to metric:")
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(value = cup.value, onValueChange = {data -> cup.value = data},
            label = {Text("Volume in cups")},
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text
            ) )
        Spacer(modifier = Modifier.height(10.dp))




        Button(

            onClick = {
                val toast = Toast.makeText(context, "that's ${cup.value.toDouble()*240} ml", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER, 0, 0)
                toast.show()
                },
            enabled = true,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.small
        ) {
            Text(text = "Calculate")
        }


        Spacer(modifier = Modifier.height(20.dp))
        Text(text = "Metric to cup measurement:")
        OutlinedTextField(value = metric.value, onValueChange = {data -> metric.value = data},
            label = {Text("Volume in ml")},
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text
            ) )


        Spacer(modifier = Modifier.height(10.dp))

        Button(

            onClick = {
                val toast = Toast.makeText(context, "that's ${metric.value.toDouble()/240} cups", Toast.LENGTH_SHORT)
                toast.setGravity(Gravity.CENTER, 0, 0)
                toast.show()
            },
            enabled = true,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.small
        ) {
            Text(text = "Calculate")
        }

    }



}


